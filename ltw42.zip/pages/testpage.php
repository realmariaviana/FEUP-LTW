<?php 
  include_once('../database/db_comments.php');

    echo bin2hex(random_bytes(10)); 

?>