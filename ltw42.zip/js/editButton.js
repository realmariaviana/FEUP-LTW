let topnav = document.querySelector('.topnav');
let editButton = document.createElement('a');
editButton.href = "../pages/editProfile.php"
editButton.innerHTML = "Edit"

topnav.appendChild(editButton);
