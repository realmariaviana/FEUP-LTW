<?php 

   // echo gmdate('Y-m-d H:i:s');
   header('Location: pages/login.php');

    ?>