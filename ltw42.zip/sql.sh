
sqlite3 -init ./database/newdb.sql  ./database/db.db
